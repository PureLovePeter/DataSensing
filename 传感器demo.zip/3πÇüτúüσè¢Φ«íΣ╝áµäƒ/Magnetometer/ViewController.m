//
//  ViewController.m
//  Magnetometer
//
//  Created by peter.zhang on 2017/9/8.
//  Copyright © 2017年 Peter. All rights reserved.
//


#import "ViewController.h"
#import <CoreMotion/CoreMotion.h>

@interface ViewController ()


/** 运动管理者 */
@property (nonatomic, strong) CMMotionManager *mgr; // 保证不死

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    /*
     Core Motion的使用步骤—push
     1.创建运动管理对象
     CMMotionManager*mgr = [[CMMotionManageralloc]init];
     2.判断磁力计是否可用(最好判断)
     if(mgr.isMagnetometerAvailable){
     //磁力计可用
     }
     3.设置采样间隔
     mgr.magnetometerUpdateInterval= 1.0/30.0;// 1秒钟采样30次
     4.开始采样(采样到数据就会调用handler，handler会在queue中执行)
     - (void)startMagnetometerUpdatesToQueue:(NSOperationQueue *)queue withHandler:(CMMagnetometerHandler)handler;
     
     */
    
    //    [self test1];
    
    
    /*
     说明 : pull是在需要时获取数据,我们此时以点击了屏幕就获取一次数据为例说明;
     1.创建运动管理对象
     CMMotionManager*mgr = [[CMMotionManageralloc]init];
     2.判断磁力计是否可用(最好判断)
     if(mgr.isMagnetometerAvailable){
     //磁力计可用
     }
     3.开始采样
     -(void)startMagnetometerUpdates;
     4.在需要时获取数据
     CMAcceleration acc = mgr.accelerometerData.acceleration;
     NSLog(@"%f,%f, %f", acc.x,acc.y,acc.z);
     */
    
    [self test2];
    
    
}

- (void)test1{
    // 1.判断磁力计是否可用
    if (!self.mgr.isMagnetometerAvailable) {
        NSLog(@"磁力计不可用");
        return;
    }
    
    // 2.设置采样间隔
    self.mgr.magnetometerUpdateInterval = 0.3;
    
    // 3.开始采样
    [self.mgr startMagnetometerUpdatesToQueue:[NSOperationQueue mainQueue] withHandler:^(CMMagnetometerData * _Nullable magnetometerData, NSError * _Nullable error) {
        // 4.获取磁力计信息
        CMMagneticField magneticField = magnetometerData.magneticField;
        NSLog(@"x=====:%f y=====:%f z====:%f", magneticField.x, magneticField.y, magneticField.z);
    }];
    
}


- (void)test2{
    // 1.判断磁力计是否可用
    if (!self.mgr.isMagnetometerAvailable) {
        NSLog(@"磁力计不可用");
        return;
    }
    
    // 2.开始采样
    [self.mgr startMagnetometerUpdates];
    
}

// 3.数据采样(以点击了屏幕为例说明)(或者使用计时器)
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    // 获取磁力计信息
    CMMagneticField magneticField = self.mgr.magnetometerData.magneticField;
    NSLog(@"x=====:%f y=====:%f z====:%f", magneticField.x, magneticField.y, magneticField.z);
}



#pragma mark - 懒加载
- (CMMotionManager *)mgr
{
    if (_mgr == nil) {
        _mgr = [[CMMotionManager alloc] init];
    }
    return _mgr;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end

