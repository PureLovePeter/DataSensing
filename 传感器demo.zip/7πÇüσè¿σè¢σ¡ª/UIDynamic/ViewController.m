//
//  ViewController.m
//  UIDynamic
//
//  Created by peter.zhang on 2017/9/15.
//  Copyright © 2017年 Peter. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
{
    UIDynamicAnimator       *_animator;        //物理仿真器
    UIGravityBehavior       *_gravity;         //重力行为
    UICollisionBehavior     *_collision;       //碰撞行为
    UIAttachmentBehavior    *_attachment;      //附着行为
    UISnapBehavior          *_snap;            //吸附行为
    UIPushBehavior          *_push;            //推行为
    UIView                  *_view;             //模拟运动的视图对象
}
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _view = [[UIView alloc] initWithFrame:CGRectMake(200, 100, 50, 50)];
    _view.backgroundColor = [UIColor blueColor];
    _view.layer.masksToBounds = YES;
    _view.layer.cornerRadius = 25;
    [self.view addSubview:_view];
    
    
    //初始化物理仿真器
    _animator = [[UIDynamicAnimator alloc] initWithReferenceView:self.view];
    
    //重力行为运动
    _gravity = [[UIGravityBehavior alloc] initWithItems:@[_view]];
     //所有行为必须添加到仿真器中才能生效
    [_animator addBehavior:_gravity];
    
    //附着行为
//    _attachment = [[UIAttachmentBehavior alloc] initWithItem:_view attachedToAnchor:CGPointMake(0, 0) ] ;
//    [_animator addBehavior:_attachment];
    
    //吸附行为
//    _snap = [[UISnapBehavior alloc] initWithItem:_view snapToPoint:CGPointMake(self.view.frame.size.width, self.view.frame.size.height)];
//    [_animator addBehavior:_snap];
    
    
    //推行为(UIPushBehaviorModeContinuous,UIPushBehaviorModeInstantaneous)
//    _push = [[UIPushBehavior alloc] initWithItems:@[_view] mode:UIPushBehaviorModeInstantaneous];
//    [_animator addBehavior:_push];
    
    
     //添加碰撞行为
    _collision = [[UICollisionBehavior alloc] initWithItems:@[_view]];
    //边界检测
    _collision.translatesReferenceBoundsIntoBoundary = YES;
    [_animator addBehavior:_collision];
}

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    //获取点击点的坐标
    CGPoint point = [[touches anyObject] locationInView:self.view];
    
    //初始化一个视图参与运动，颜色随机
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 50, 50)];
    view.layer.masksToBounds = YES;
    view.layer.cornerRadius = 25;
    view.center = point;
    CGFloat red = arc4random()% 200 + 55;
    CGFloat green = arc4random()% 200 + 55;
    CGFloat blue = arc4random()% 200 + 55;
    view.backgroundColor = [UIColor colorWithRed:red/255.0 green:green/255.0 blue:blue/255.0 alpha:1.0];
    [self.view addSubview:view];
    
    //添加重力行为
    [_gravity addItem:view];
    
    //添加碰撞行为
    [_collision addItem:view];
    
    //添加推行为
//    [_push addItem:view];
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
