//
//  ViewController.m
//  Gyroscope
//
//  Created by peter.zhang on 2017/9/8.
//  Copyright © 2017年 Peter. All rights reserved.
//

#import "ViewController.h"
#import <CoreMotion/CoreMotion.h>

//更具重力加速小球

@interface ViewController ()<UIAccelerometerDelegate>

@property (weak, nonatomic) IBOutlet UIView *ball;


@property (assign, nonatomic) CGPoint volecity;

/** 运动管理者 */
@property (nonatomic, strong) CMMotionManager *mgr; // 保证不死

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self test1];
}
#pragma mark - 懒加载
- (CMMotionManager *)mgr
{
    if (_mgr == nil) {
        _mgr = [[CMMotionManager alloc] init];
    }
    return _mgr;
}


- (void)test1{
    //设置小球的属性
    _ball.frame = CGRectMake(10, 10, 40, 40);
    _ball.layer.masksToBounds = YES;
    _ball.layer.cornerRadius = 20;
    
    
    // 1.判断加速计是否可用
    if (!self.mgr.isAccelerometerAvailable) {
        NSLog(@"加速计不可用");
        return;
    }
    
    // 2.设置采样间隔
    self.mgr.accelerometerUpdateInterval = 1/60;
    
    // 3.开始采样
    [self.mgr startAccelerometerUpdatesToQueue:[NSOperationQueue mainQueue] withHandler:^(CMAccelerometerData *accelerometerData, NSError *error) { // 当采样到加速计信息时就会执行
        if (error) return;
        
//        // 4.获取加速计信息
        CMAcceleration acceleration = accelerometerData.acceleration;
//          NSLog(@"x加速度%f--y加速度%f--z加速度%f",acceleration.x,acceleration.y,acceleration.z);
        
        
         _volecity.x += acceleration.x;
         _volecity.y += acceleration.y;
        CGFloat ballX = self.ball.frame.origin.x + _volecity.x;
        CGFloat ballY = self.ball.frame.origin.y - _volecity.y;
        NSLog(@"x坐标:%f,y坐标:%f",ballX,ballY);
        self.ball.frame = CGRectMake(ballX, ballY, 40, 40);
        
        if(CGRectGetMinX(self.ball.frame)<=0){
            _volecity.x = 0;
            if(CGRectGetMinY(self.ball.frame)<=0){
                self.ball.frame = CGRectMake(0, 0, 40, 40);
            }else if(CGRectGetMaxY(self.ball.frame)>=self.view.frame.size.height){
                self.ball.frame = CGRectMake(0, self.view.frame.size.height - 40, 40, 40);
            }else{
                self.ball.frame = CGRectMake(0, ballY, 40, 40);
            }
        }
        if (CGRectGetMinY(self.ball.frame)<=0) {
            _volecity.y = 0;
            if (CGRectGetMinX(self.ball.frame)<=0) {
                self.ball.frame = CGRectMake(0, 0, 40, 40);
            }else if(CGRectGetMaxX(self.ball.frame)>=self.view.frame.size.width){
                self.ball.frame = CGRectMake(self.view.frame.size.width - 40, 0, 40, 40);
            }else{
                self.ball.frame = CGRectMake(ballX, 0, 40, 40);
            }
        }
        if (CGRectGetMaxX(self.ball.frame)>=self.view.frame.size.width) {
            _volecity.x = 0;
            if (CGRectGetMinY(self.ball.frame)<=0) {
                self.ball.frame = CGRectMake(self.view.frame.size.width - 40, 0, 40, 40);
            }else if(CGRectGetMaxY(self.ball.frame)>=self.view.frame.size.height){
                self.ball.frame = CGRectMake(self.view.frame.size.width - 40, self.view.frame.size.height - 40, 40, 40);
            }else{
                self.ball.frame = CGRectMake(self.view.frame.size.width - 40, ballY, 40, 40);
            }
        }
        if (CGRectGetMaxY(self.ball.frame)>=self.view.frame.size.height) {
            _volecity.y = 0;
            if (CGRectGetMaxX(self.ball.frame)>=self.view.frame.size.width) {
                self.ball.frame = CGRectMake(self.view.frame.size.width - 40, self.view.frame.size.height - 40, 40, 40);
            }else if(CGRectGetMinX(self.ball.frame)<=0){
                self.ball.frame = CGRectMake(0, self.view.frame.size.height - 40, 40, 40);
            }else{
                self.ball.frame = CGRectMake(ballX, self.view.frame.size.height - 40, 40, 40);
            }
        }
        
    }];
    
}



@end
