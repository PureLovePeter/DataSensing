//
//  ViewController.m
//  Proximity
//
//  Created by peter.zhang on 2017/9/8.
//  Copyright © 2017年 Peter. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

//距离传感器
/**
 1、使用前要打开当前设备距离传感器的开关(默认为:NO)
 2、监听方式:添加观察者,监听通知（UIDeviceProximityStateDidChangeNotification）
 3、监听状态:观察者的对应回调方法中,判断[UIDevice currentDevice].proximityState
 */
- (void)viewDidLoad {
    [super viewDidLoad];
    
    /*@1*/
    [UIDevice currentDevice].proximityMonitoringEnabled = YES;
    
    /*@2*/
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(proximityStateDidChange) name:UIDeviceProximityStateDidChangeNotification object:nil];
}

/**
 @3
 当物体靠近的时候屏幕黑，控制台输出：有物品靠近
 当物体离开的时候屏幕亮，控制台输出：有物品离开
 */
- (void)proximityStateDidChange
{
    if ([UIDevice currentDevice].proximityState) {
        NSLog(@"有物品靠近");
    } else {
        NSLog(@"有物品离开");
    }
}



@end
